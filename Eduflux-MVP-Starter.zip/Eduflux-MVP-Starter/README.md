# Eduflux MVP

This is a minimal React starter project for Eduflux.