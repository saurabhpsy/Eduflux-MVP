import React from 'react';
import ReactDOM from 'react-dom/client';

const App = () => {
  return <h1>Welcome to Eduflux MVP</h1>;
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);